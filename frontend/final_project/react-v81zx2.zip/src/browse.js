import React, { useState } from 'react';

export default function Browse() {
  return (
    <div id="Browse">
      <h1>[ Spotlight ]</h1>
      <div id="top"></div>
      <div id="genre">
        <div className="browsebooks">
          <h2>Genre of the Month</h2>

          <h3 className="genre">
            <em>Fantasy/Science Fiction</em>
          </h3>
          <div className="glider">
            <div className="glider-track">
              <div className="book-slide">
                <img
                  className="books"
                  src="https://m.media-amazon.com/images/I/51UrTnJIgcL._SY291_BO1,204,203,200_QL40_FMwebp_.jpg"
                  alt="Ready Player One"
                ></img>
                <h3 className="novel">Ready Player One (Paperback)</h3>
                <p>
                  <em>Ernest Cline</em>
                </p>
                <p>$17</p>
              </div>
              <div className="book-slide">
                <img
                  className="books"
                  src="https://m.media-amazon.com/images/I/4164GkhDBXL._SY291_BO1,204,203,200_QL40_FMwebp_.jpg"
                  alt="The Martian"
                ></img>
                <h3 className="novel">The Martian (Paperback)</h3>
                <p>
                  <em>Andy Weir</em>
                </p>
                <p>$18</p>
              </div>
              <div className="book-slide">
                <img
                  className="books"
                  src="https://m.media-amazon.com/images/I/81ym3QUd3KL._AC_UF1000,1000_QL80_.jpg"
                  alt="Dune"
                ></img>
                <h3 className="novel">Dune (Paperback)</h3>
                <p>
                  <em>Frank Herbert</em>
                </p>
                <p>$11</p>
              </div>
              <div className="book-slide">
                <img
                  className="books"
                  src="https://m.media-amazon.com/images/I/713fuKZOVpL._AC_UF1000,1000_QL80_.jpg"
                  alt="The Fellowship of the Ring"
                ></img>
                <h3 className="novel">The Fellowship of the Ring (Paperback)</h3>
                <p>
                  <em>J.R.R. Tolkien</em>
                </p>
                <p>$18</p>
              </div>
              <div className="book-slide">
                <img
                  className="books"
                  src="https://m.media-amazon.com/images/I/51YfSAtW63L.jpg"
                  alt="Ender's Game"
                ></img>
                <h3 className="novel">Ender's Game (Paperback)</h3>
                <p>
                  <em>Orson Scott Card</em>
                </p>
                <p>$17</p>
              </div>
              <div className="book-slide">
                <img
                  className="books"
                  src="https://m.media-amazon.com/images/I/51016lbT2fL._SY346_.jpg"
                  alt="Book 5"
                ></img>
                <h3 className="novel">Babel (Hardcover)</h3>
                <p>
                  <em>R.F. Kuang</em>
                </p>
                <p>$20</p>
              </div>
            </div>
          </div>
          <div className="browsebooks">
            <h2>Author of the Month</h2>

            <h3 className="genre">
              <em>R.F. Kuang</em>
            </h3>
            <div className="glider">
              <div className="glider-track">
                <div className="book-slide">
                  <img
                    className="books"
                    src="https://m.media-amazon.com/images/I/415sNT7bPjL._SY291_BO1,204,203,200_QL40_FMwebp_.jpg"
                    alt="The Poppy War"
                  ></img>
                  <h3 className="novel">The Poppy War (Paperback)</h3>
                  <p>
                    <em>R.F. Kuang</em>
                  </p>
                  <p>$15</p>
                </div>
                <div className="book-slide">
                  <img
                    className="books"
                    src="https://m.media-amazon.com/images/I/41B7aPHTmvL._SY291_BO1,204,203,200_QL40_FMwebp_.jpg"
                    alt="The Dragon Republic"
                  ></img>
                  <h3 className="novel">The Dragon Republic (Paperback)</h3>
                  <p>
                    <em>R.F. Kuang</em>
                  </p>
                  <p>$15</p>
                </div>
                <div className="book-slide">
                  <img
                    className="books"
                    src="https://m.media-amazon.com/images/I/41aiDEsgWJL._SY291_BO1,204,203,200_QL40_FMwebp_.jpg"
                    alt="The Burning God"
                  ></img>
                  <h3 className="novel">The Burning God (Paperback)</h3>
                  <p>
                    <em>R.F. Kuang</em>
                  </p>
                  <p>$16</p>
                </div>
                <div className="book-slide">
                  <img
                    className="books"
                    src="https://m.media-amazon.com/images/I/51016lbT2fL._SY346_.jpg"
                    alt="Book 5"
                  ></img>
                  <h3 className="novel">Babel (Hardcover)</h3>
                  <p>
                    <em>R.F. Kuang</em>
                  </p>
                  <p>$18</p>
                </div>
                <div className="book-slide">
                  <img
                    className="books"
                    src="https://m.media-amazon.com/images/I/6177TdosPJL._SL1500_.jpg"
                    alt="No Image"
                  ></img>
                  <h3 className="novel">Yellowface (Hardcover)</h3>
                  <p>R.F. Kuang</p>
                  <p>$22</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
