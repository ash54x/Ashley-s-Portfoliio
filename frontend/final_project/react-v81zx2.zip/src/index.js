import React from 'react';
import { createRoot } from 'react-dom/client';

import './index.css';
import Browse from './browse.js';
import SearchBar from './searchbar.js';
import Subscribe from './subscribe.js';
import Nav from './nav.js';

const root = createRoot(document.querySelector('#root'));

root.render(
  <React.StrictMode>
    <div id="nav-wrapper">
      <Nav />
    </div>

    <div id="header">
      <div id="text">
        <h1>
          <em>
            <strong> The Book Trade</strong>
          </em>
        </h1>
        <p>
          Welcome to your personal online book community, where you can find and
          leave reviews of your favorite books!
        </p>
      </div>
    </div>

    <div id="content">
      <Browse />
      <hr />
      <SearchBar />

      <hr />
      <Subscribe />
    </div>

    <div id="footer">
      <p>&copy; 2022 Ashley Chen. All Rights Reserved.</p>
    </div>
  </React.StrictMode>
);
