import React, { useState } from 'react';

export default function Nav() {
  return (
    <div id="nav-wrapper">
      <div id="nav">
        <a href="#nav-wrapper">
          <strong>Home</strong>
        </a>
        <a href="#Browse">
          <strong>Spotlight</strong>
        </a>
        <a href="#Search">
          <strong>Search</strong>
        </a>
        <a href="#Subscribe">
          <strong>Review!</strong>
        </a>
      </div>
    </div>
  );
}
