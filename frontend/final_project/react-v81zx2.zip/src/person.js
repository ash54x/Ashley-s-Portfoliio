export default class Person {
  fullName;
  contact = {};
  Comment;

  constructor(fName) {
    this.fullName = fName;
  }

  setEmail(_email) {
    this.contact.email = _email;
  }

  setComments(comment) {
    this.Comment = comment;
  }

  getfullName() {
    return this.fullName;
  }

  getComments() {
    return this.Comment;
  }

  getContactInfo() {
    var info = '';

    if (this.contact.email != undefined) {
      info = this.contact.email;
    }

    return info;
  }
}
