import React from 'react';
import { useState } from 'react';
import $ from 'jquery';

export default function SearchBar() {
  const [searchTerm, setSearchTerm] = useState('');
  const [results, setResults] = useState([]);

  function handleOnSubmit(e) {
    e.preventDefault();

    $.ajax({
      url:
        'https://www.googleapis.com/books/v1/volumes?q=search+terms=' +
        encodeURI(searchTerm),
      dataType: 'json',
      success: function (response) {
        setResults(response.items);
      },
      error: function (error) {
        alert('AJAX Error');
        console.log(error);
      },
    });
  }

  return (
    <div id="Search">
      <div className="searchbar">
        <form id="search-form" onSubmit={handleOnSubmit}>
          <div className="form-row">
            <div className="bar">
              <label htmlFor="search-term" id="labelSearch">
                <h2>Search:</h2>
              </label>
              <input
                type="text"
                className="form-control"
                id="searchTerm"
                placeholder="Search..."
                name="searchTerm"
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.currentTarget.value);
                }}
              />
            </div>
            <div className="search">
              <button type="submit" id="searchButton">
                Search
              </button>
            </div>
          </div>
        </form>
      </div>
      <div className="search">
        <table className="table" id="searchTable">
          <thead>
            <tr>
              <th className="slot"> </th>
              <th className="slot">Title</th>
              <th className="slot">Author</th>
              <th className="slot">Price</th>
              <th className="slot">Ratings</th>
            </tr>
          </thead>
          <tbody>
            {results.map((book) => (
              <tr key={book.id}>
                <td>
                  <img
                    src={book?.volumeInfo?.imageLinks?.thumbnail}
                    alt={book.volumeInfo.title}
                  />
                </td>
                <td>{book.volumeInfo.title}</td>
                <td>{book?.volumeInfo?.authors?.[0]}</td>
                <td>${book.saleInfo.listPrice?.amount || 'N/A'}</td>
                <td>{book.volumeInfo.averageRating || 'N/A'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
