import React, { useState } from 'react';
import Person from './person.js';

export default function Subscribe() {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [comment, setComments] = useState('');
  const [contacts, setContacts] = useState([]);

  function handleOnSubmit(e) {
    e.preventDefault();

    if (fullName.length == 0 || fullName.trim().split(' ').length < 2) {
      alert('First and last names are required.');
    } else {
      var tmpPerson = new Person(fullName);

      if (email.length === 0 || email.indexOf('@') === -1) {
        alert('Email is required');
      } else {
        tmpPerson.setEmail(email);
      }

      if (comment.length == 0) {
        alert('Please leave a review')
      } else {
        tmpPerson.setComments(comment);
      }

      setContacts([...contacts, tmpPerson]);

      setFullName('');
      setEmail('');
      setComments('');
    }
  }

  return (
    <div id="Subscribe">
      <h2>Leave a Review!</h2>
      <form onSubmit={handleOnSubmit}>
        <div className="form-row">
          <label className="main-label" htmlFor="name">
            Name:
          </label>
          <input
            className="subscribeBoxes"
            id="name"
            type="text"
            onChange={(e) => {
              setFullName(e.currentTarget.value);
            }}
            value={fullName}
          ></input>
        </div>

        <div className="form-row">
          <label className="main-label" htmlFor="email">
            Email:
          </label>
          <input
          className="subscribeBoxes"
            id="email"
            type="text"
            onChange={(e) => {
              setEmail(e.currentTarget.value);
            }}
            value={email}
          ></input>
        </div>


        <div className="comments">
          <label htmlFor="comment" ß>
            Book and Review:
          </label>
          <div className="textbox">
            <textarea
              id="comment"
              onChange={(e) => {
                setComments(e.currentTarget.value);
              }}
              value={comment}
            ></textarea>
          </div>
        </div>

        <div className="form-row">
          <button id="submit" type="submit">
            Submit!
          </button>
        </div>
      </form>

      <div id="list">
        <h2>Reviews</h2>

        <div id="contactList">
          <table id="table">
            <thead>
              <tr>
                <th className="title">
                  <em>Name</em>
                </th>
                <th className="title">
                  <em>Email</em>
                </th>
                <th className="title">
                  <em>Review</em>
                </th>
                <th></th>
              </tr>
            </thead>

            <tbody>
              {contacts.map((elt, idx) => {
                return (
                  <tr>
                    <td>{elt.getfullName()}</td>
                    <td>{elt.getContactInfo()}</td>
                    <td>{elt.getComments()}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
